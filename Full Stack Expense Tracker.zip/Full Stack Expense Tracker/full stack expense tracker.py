import tkinter as tk
from tkinter import messagebox
import matplotlib.pyplot as plt


def show_chart(expense_dict):
    categories = list(expense_dict.keys())
    amounts = list(expense_dict.values())
    
    # Create a pie chart
    plt.figure(figsize=(8, 8))
    plt.pie(amounts, labels=categories, autopct='%1.1f%%', startangle=140)
    plt.title("Category Wise Expense Distribution")
    plt.axis('equal')  # Equal aspect ratio ensures that pie chart is circular
    plt.show()

def add_expense():
    category = entry_category.get()
    amount = entry_amount.get()
    
    if not category or not amount:
        messagebox.showerror("Input Error", "Please fill all fields")
        return
    
    try:
        amount = float(amount)
    except ValueError:
        messagebox.showerror("Input Error", "Amount must be a number")
        return

    
    if category in expenses:
        expenses[category] += amount
    else:
        expenses[category] = amount
    
    
    entry_category.delete(0, tk.END)
    entry_amount.delete(0, tk.END)

def generate_chart():
    if not expenses:
        messagebox.showinfo("Data Error", "No expenses added.")
        return
    show_chart(expenses)


root = tk.Tk()
root.title("Expense Tracker")
expenses = {}


tk.Label(root, text="Category:").grid(row=0, column=0, padx=10, pady=10)
entry_category = tk.Entry(root)
entry_category.grid(row=0, column=1, padx=10, pady=10)

tk.Label(root, text="Amount:").grid(row=1, column=0, padx=10, pady=10)
entry_amount = tk.Entry(root)
entry_amount.grid(row=1, column=1, padx=10, pady=10)

tk.Button(root, text="Add Expense", command=add_expense).grid(row=2, column=0, padx=10, pady=10)
tk.Button(root, text="Show Pie Chart", command=generate_chart).grid(row=2, column=1, padx=10, pady=10)


root.mainloop()



